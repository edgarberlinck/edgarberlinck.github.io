﻿var BlockUI = {
    show : function()
    {
        var block = document.getElementById("blockUI");
        block.style.display = "block";
        block.style.height = document.body.offsetHeight + "px";
    },
    hide : function()
    {
        document.getElementById("blockUI").style.display = "none";
    }
};