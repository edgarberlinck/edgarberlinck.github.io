﻿function SomeJS()
{
    alert("Hi I am from SomeJS");
}